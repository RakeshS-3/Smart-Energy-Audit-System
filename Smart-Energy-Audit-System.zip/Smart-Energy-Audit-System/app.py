from pathlib import Path
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="Smart Energy Audit System", page_icon="⚡", layout="wide")
DATA_FILE = Path(__file__).parent / "data" / "sample_readings.csv"

@st.cache_data
def read_data():
    data = pd.read_csv(DATA_FILE, parse_dates=["timestamp"])
    for col in ["power_w", "energy_kwh"]:
        data[col] = pd.to_numeric(data[col], errors="coerce")
    return data.dropna(subset=["timestamp", "load_name", "power_w", "energy_kwh"])

df = read_data()
st.title("⚡ Smart Energy Audit System")
st.caption("Energy-audit dashboard prototype • Sample data only; no live electrical measurements.")

with st.sidebar:
    st.header("Audit settings")
    all_loads = sorted(df["load_name"].unique())
    selected_loads = st.multiselect("Loads to include", all_loads, default=all_loads)
    tariff = st.number_input("Tariff (₹ per kWh)", min_value=0.0, value=8.0, step=0.5)
    saving_percent = st.slider("What-if energy saving", 0, 40, 10, 5)

filtered = df[df["load_name"].isin(selected_loads)].copy()
if filtered.empty:
    st.warning("Choose at least one load in the sidebar.")
    st.stop()

total_energy = filtered["energy_kwh"].sum()
estimated_bill = total_energy * tariff
average_power = filtered["power_w"].mean()
potential_saving = total_energy * saving_percent / 100

a, b, c, d = st.columns(4)
a.metric("Energy consumed", f"{total_energy:,.2f} kWh")
b.metric("Estimated bill", f"₹{estimated_bill:,.2f}")
c.metric("Average recorded power", f"{average_power:,.0f} W")
d.metric("Potential energy saving", f"{potential_saving:,.2f} kWh",
         help="Illustrative estimate based on the selected saving percentage.")

by_load = filtered.groupby("load_name", as_index=False).agg(
    energy_kwh=("energy_kwh", "sum"),
    average_power_w=("power_w", "mean")
)
by_load["estimated_cost_inr"] = by_load["energy_kwh"] * tariff
by_load["share_percent"] = by_load["energy_kwh"] / total_energy * 100 if total_energy else 0

st.subheader("Energy use by load")
st.plotly_chart(
    px.bar(by_load.sort_values("energy_kwh", ascending=False), x="load_name", y="energy_kwh",
           labels={"load_name": "Load", "energy_kwh": "Energy (kWh)"},
           title="Total energy consumption by equipment"),
    use_container_width=True
)

left, right = st.columns(2)
with left:
    st.subheader("Estimated cost by load")
    st.plotly_chart(
        px.pie(by_load, names="load_name", values="estimated_cost_inr",
               title="Share of estimated energy cost"),
        use_container_width=True
    )
with right:
    st.subheader("Consumption over time")
    timeline = filtered.groupby("timestamp", as_index=False)["energy_kwh"].sum()
    st.plotly_chart(
        px.line(timeline, x="timestamp", y="energy_kwh", markers=True,
                labels={"timestamp": "Time", "energy_kwh": "Energy (kWh)"},
                title="Recorded energy by interval"),
        use_container_width=True
    )

st.subheader("Audit observations")
if not by_load.empty and total_energy > 0:
    top = by_load.sort_values("energy_kwh", ascending=False).iloc[0]
    st.write(f"**Highest energy use:** {top['load_name']} accounts for {top['share_percent']:.1f}% of the selected energy.")
    st.write("Suggested audit action: check operating hours, unnecessary standby use, maintenance condition, and whether the load is appropriately sized.")
else:
    st.write("No energy usage recorded for the selected loads.")

st.subheader("Load summary")
st.dataframe(by_load.sort_values("energy_kwh", ascending=False).round(2), use_container_width=True)
st.download_button(
    "Download selected readings (CSV)",
    data=filtered.to_csv(index=False).encode("utf-8"),
    file_name="energy_audit_readings.csv",
    mime="text/csv"
)
st.info("Bills are estimates using the tariff you enter and exclude fixed charges, taxes, demand charges, and tariff slabs.")
