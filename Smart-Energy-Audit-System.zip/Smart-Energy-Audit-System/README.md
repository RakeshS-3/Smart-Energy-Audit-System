# Smart Energy Audit System

A beginner-friendly Python dashboard that demonstrates how an energy auditor can review electricity usage, estimate bills, compare loads, and identify equipment with high energy consumption.

**Important:** This is a software prototype using sample/simulated readings. It does not measure real voltage or current and is not connected to live electrical equipment.

## Features
- Dashboard KPIs for energy use, estimated bill, and average power
- Load-wise energy and cost comparison
- Adjustable tariff and energy-saving scenario
- High-consumption load identification
- Download filtered sample readings as CSV

## Technology
- Python 3.10+
- Streamlit
- Pandas
- Plotly

## Run locally
1. Extract the ZIP.
2. Open a terminal in the extracted folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run:
   ```bash
   streamlit run app.py
   ```
5. Open the local address shown in the terminal.

## Data format
`data/sample_readings.csv` includes:
- `timestamp`: date and time of the reading
- `load_name`: equipment/load name
- `power_w`: simulated instantaneous power in watts
- `energy_kwh`: energy used during the interval in kWh
- `location`: room or area

Replace the sample data with authorized meter readings if available. Check units and time intervals before comparing readings.

## Safety
Do not connect a computer, microcontroller, or prototype directly to mains voltage. Real electrical measurements must use appropriately rated, isolated equipment and be installed or supervised by a qualified person.

## Upload to GitHub
Create a repository named `Smart-Energy-Audit-System`, then upload the extracted files and folders (not only the ZIP).
